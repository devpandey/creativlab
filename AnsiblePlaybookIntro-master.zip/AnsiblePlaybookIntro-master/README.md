# Ansible Playbook Intro
This vagrant lab has been created to become familiar with Ansible Ad-hoc configurations. Please visit  http://ranix.net/software/ansible-playbook-intro for more information.
